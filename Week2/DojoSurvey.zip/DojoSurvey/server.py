from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key ="ashdalh"

@app.route('/')
def index():
  return render_template("index.html")

@app.route('/users', methods=["POST"])
def users():
    session["name"]=request.form["name"]
    session["location"]=request.form["location"]
    session["language"]=request.form["language"]
    #session["comments"]=request.form["comments"]
    
    return redirect('/results')

@app.route('/results')
def results():
    return render_template('results.html',name=session["name"],location=session["location"],language=session["language"])#,comments=session["comments"])
    
app.run(debug=True)    
